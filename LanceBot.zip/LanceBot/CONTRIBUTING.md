# Guia de Contribuição

## 📌 Primeira Contribuição?
1. Procure por issues com `good first issue`
2. Comente na issue dizendo "Vou trabalhar nisso"
3. Siga o [tutorial GitHub](https://guides.github.com/activities/hello-world/)

## 🛠️ Configuração
```bash
git clone https://github.com/RodrigoRMarinho/LanceBot.git
cd LanceBot
pip install -r requirements.txt  # Python
npm install                     # Electron
