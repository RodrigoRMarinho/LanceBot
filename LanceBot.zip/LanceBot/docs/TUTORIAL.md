# 🎥 Tutorial de Configuração

## Seção 1: Ambiente de Desenvolvimento
```bash
# Demonstre:
git clone https://github.com/RodrigoRMarinho/LanceBot.git
cd LanceBot
npm install
playwright install
## Seção 2: Primeira Execução

### ▶️ Iniciando o LanceBot
```bash
npm start
# Ou para modo desenvolvimento:
npm run dev
