# Pelo GitHub:
Settings > Collaborators > Add people