# Dentro da pasta do projeto:
touch LICENSE.md CONTRIBUTING.md CODE_OF_CONDUCT.md