"""
Módulo de inicialização para o Portal de Compras Públicas.

Este módulo exporta as classes e funções necessárias para
interagir com o Portal de Compras Públicas.
"""

from .portal import PortalComprasPublicas

__all__ = ['PortalComprasPublicas']
