"""
Módulo de inicialização para o portal ComprasNet.

Este módulo exporta as classes e funções necessárias para
interagir com o portal ComprasNet.
"""

from .portal import ComprasNetPortal

__all__ = ['ComprasNetPortal']
