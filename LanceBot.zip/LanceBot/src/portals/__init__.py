"""
Módulo base para interação com portais de licitação.

Este módulo define a interface comum para todos os portais de licitação
suportados pelo LanceBot, garantindo uma API consistente.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Union, Any
import os
import json
from datetime import datetime

from ..core.logger import LanceLogger


class PortalBase(ABC):
    """
    Classe base abstrata para todos os portais de licitação.
    
    Define a interface comum que deve ser implementada por todos os
    portais específicos suportados pelo LanceBot.
    """
    
    def __init__(self, logger: Optional[LanceLogger] = None):
        """
        Inicializa a classe base do portal.
        
        Args:
            logger: Instância do logger para registrar eventos
        """
        self.logger = logger or LanceLogger()
        self.logged_in = False
        self.session_data = {}
        
    @abstractmethod
    def login(self, username: str, password: str) -> bool:
        """
        Realiza login no portal.
        
        Args:
            username: Nome de usuário ou CPF/CNPJ
            password: Senha de acesso
            
        Returns:
            True se login bem-sucedido, False caso contrário
        """
        pass
    
    @abstractmethod
    def login_with_certificate(self, certificate_path: str, certificate_password: Optional[str] = None) -> bool:
        """
        Realiza login no portal usando certificado digital.
        
        Args:
            certificate_path: Caminho para o arquivo do certificado
            certificate_password: Senha do certificado, se necessário
            
        Returns:
            True se login bem-sucedido, False caso contrário
        """
        pass
    
    @abstractmethod
    def search_auctions(self, 
                       keywords: Optional[List[str]] = None, 
                       start_date: Optional[datetime] = None,
                       end_date: Optional[datetime] = None,
                       auction_type: Optional[str] = None) -> List[Dict]:
        """
        Busca licitações no portal.
        
        Args:
            keywords: Lista de palavras-chave para busca
            start_date: Data de início para filtro
            end_date: Data de fim para filtro
            auction_type: Tipo de licitação (pregão, dispensa, etc.)
            
        Returns:
            Lista de licitações encontradas
        """
        pass
    
    @abstractmethod
    def get_auction_details(self, auction_id: str) -> Dict:
        """
        Obtém detalhes de uma licitação específica.
        
        Args:
            auction_id: Identificador da licitação
            
        Returns:
            Dicionário com detalhes da licitação
        """
        pass
    
    @abstractmethod
    def submit_proposal(self, 
                       auction_id: str, 
                       item_id: str,
                       price: float,
                       additional_data: Optional[Dict] = None) -> bool:
        """
        Submete uma proposta para um item de licitação.
        
        Args:
            auction_id: Identificador da licitação
            item_id: Identificador do item
            price: Valor da proposta
            additional_data: Dados adicionais específicos do portal
            
        Returns:
            True se proposta enviada com sucesso, False caso contrário
        """
        pass
    
    @abstractmethod
    def get_auction_status(self, auction_id: str) -> Dict:
        """
        Obtém o status atual de uma licitação.
        
        Args:
            auction_id: Identificador da licitação
            
        Returns:
            Dicionário com status atual da licitação
        """
        pass
    
    @abstractmethod
    def get_current_price(self, auction_id: str, item_id: str) -> float:
        """
        Obtém o preço atual de um item em licitação.
        
        Args:
            auction_id: Identificador da licitação
            item_id: Identificador do item
            
        Returns:
            Preço atual do item
        """
        pass
    
    @abstractmethod
    def submit_bid(self, 
                  auction_id: str, 
                  item_id: str,
                  price: float) -> bool:
        """
        Submete um lance para um item em licitação.
        
        Args:
            auction_id: Identificador da licitação
            item_id: Identificador do item
            price: Valor do lance
            
        Returns:
            True se lance enviado com sucesso, False caso contrário
        """
        pass
    
    @abstractmethod
    def get_messages(self, auction_id: str) -> List[Dict]:
        """
        Obtém mensagens do chat da licitação.
        
        Args:
            auction_id: Identificador da licitação
            
        Returns:
            Lista de mensagens do chat
        """
        pass
    
    @abstractmethod
    def send_message(self, auction_id: str, message: str) -> bool:
        """
        Envia mensagem para o chat da licitação.
        
        Args:
            auction_id: Identificador da licitação
            message: Texto da mensagem
            
        Returns:
            True se mensagem enviada com sucesso, False caso contrário
        """
        pass
    
    @abstractmethod
    def get_ranking(self, auction_id: str, item_id: str) -> List[Dict]:
        """
        Obtém o ranking atual de lances para um item.
        
        Args:
            auction_id: Identificador da licitação
            item_id: Identificador do item
            
        Returns:
            Lista com ranking de lances
        """
        pass
    
    def save_session(self, filepath: Optional[str] = None) -> bool:
        """
        Salva dados da sessão em arquivo.
        
        Args:
            filepath: Caminho para o arquivo de sessão
            
        Returns:
            True se sessão salva com sucesso, False caso contrário
        """
        if not self.logged_in or not self.session_data:
            self.logger.warning("Tentativa de salvar sessão sem estar logado")
            return False
            
        if filepath is None:
            # Cria diretório de sessões se não existir
            session_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "sessions")
            os.makedirs(session_dir, exist_ok=True)
            
            # Nome do arquivo baseado no portal e timestamp
            portal_name = self.__class__.__name__.lower()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = os.path.join(session_dir, f"{portal_name}_{timestamp}.json")
        
        try:
            with open(filepath, 'w') as f:
                json.dump(self.session_data, f)
            self.logger.info(f"Sessão salva em {filepath}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao salvar sessão: {str(e)}")
            return False
    
    def load_session(self, filepath: str) -> bool:
        """
        Carrega dados de sessão de arquivo.
        
        Args:
            filepath: Caminho para o arquivo de sessão
            
        Returns:
            True se sessão carregada com sucesso, False caso contrário
        """
        try:
            with open(filepath, 'r') as f:
                self.session_data = json.load(f)
            self.logged_in = True
            self.logger.info(f"Sessão carregada de {filepath}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao carregar sessão: {str(e)}")
            return False
