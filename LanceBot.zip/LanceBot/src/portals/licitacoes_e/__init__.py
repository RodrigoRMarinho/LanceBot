"""
Módulo de inicialização para o portal Licitações-e.

Este módulo exporta as classes e funções necessárias para
interagir com o portal Licitações-e do Banco do Brasil.
"""

from .portal import LicitacoesEPortal

__all__ = ['LicitacoesEPortal']
