"""
Módulo de inicialização para o portal BLL Compras.

Este módulo exporta as classes e funções necessárias para
interagir com o portal BLL Compras.
"""

from .portal import BLLComprasPortal

__all__ = ['BLLComprasPortal']
