# 🤖 LanceBot - Robô de Licitações Públicas
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)

Projeto open source para automatização de licitações públicas...

## 📌 Como Contribuir
- Veja nosso [guia de contribuição](CONTRIBUTING.md)
- Participe das [discussões abertas](https://github.com/RodrigoRMarinho/LanceBot/discussions)